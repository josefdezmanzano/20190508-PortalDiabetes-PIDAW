<?php $__env->startSection('content'); ?>
<div class="container">
        <center><h1 style="text-align: center;font-family: 'Staatliches', cursive;">Actualizar información personal</h1></center>

            <form name="f1" action="<?php echo e(route('user.update', $user->id)); ?>" enctype="multipart/form-data" method="POST">
                        <!-- CONTROLAMOS LOS ERRORES DEL VALIDATE STORE -->
                        <?php if($errors->any): ?>
                        <div>

                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $el_error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="alert alert-danger"><?php echo e($el_error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>

                        </div>
                        <?php endif; ?>
                        <?php echo method_field('PUT'); ?> <!--comprobar -->
                        <!--<input name="_method" type="hidden" value="PUT">-->
                        <div class="form-group">
                        <label for="titulo">Nombre </label>
                        <input type="text" name="name" class="form-control" id="exampleFormControlFile1" value="<?php echo e($user->name); ?>">
                     </div>

                 <div class="form-group">
                        <label for="sinopsis">Email </label>
                  <input type="text" name="email" class="form-control" id="exampleFormControlFile1" value="<?php echo e($user->email); ?>">
                     </div>

                 <div class="form-group">
                        <label for="stock">Diabetico? </label>
                        <select id="diabetic" name='diabetic' class="custom-select" id="inputGroupSelect01">
                                <!-- comprobamos lo que tiene actualmente-->
                                <?php if($user->diabetic=='SI'): ?>
                                <option selected value="SI">SI</option>
                                <option value="NO">NO</option>
                                <?php else: ?>
                                <option value="SI">SI</option>
                                <option selected value="NO">NO</option>
                                <?php endif; ?>

                            </select>
               </div>
        <div class="form-group">
            <label for="Portada">Foto perfil</label>
       <img style="border-radius: 50px 50px; margin:1%;" src=<?php echo e(asset($user->image)); ?> height="50" width="50">

       <div class="input-group mb-3">
            <div class="custom-file">
              <input type="file" class="custom-file-input" id="inputGroupFile03" aria-describedby="inputGroupFileAddon03" name='image'>
              <label class="custom-file-label" for="inputGroupFile03">Elige un archivo</label>
            </div>
          </div>
          </div>
            <div class="form-group">
                  <input type="submit"  name="btn_env" class="btn btn-success" id="exampleFormControlFile1">
            <a href="<?php echo e(route('user.show',$user->id)); ?>" class="btn btn-info">Volver</a>
            </div>
                    <?php echo csrf_field(); ?>
                </form>
        </div>
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/josefdez/public_html/repositorios/laravel/20190508-PortalDiabetes-PIDAW/PortalDiabetes/resources/views/user/edit.blade.php ENDPATH**/ ?>