<?php $__env->startSection('content'); ?>
<div class="container">
        <?php if($errors->any): ?>
        <div>

        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $el_error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="alert alert-danger"><?php echo e($el_error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

        </div>
        <?php endif; ?>
        <div class="table-responsive-xl text-center p-3 mb-2">
                <center><h2><?php echo e($user->name); ?></h2></center>

       <img style="border-radius: 50px 50px; margin:1%;" src=<?php echo e(asset($user->image)); ?> height="150" width="150">


       <table class="table table-borderless table-hover table-dark" style="border-radius: 10px 10px; margin-top:1%;" >
            <thead>
            <tr>
              <th>Email</th>
              <th>Diabetico</th>
              <th>Fecha de ingreso</th>
            </tr>
        </thead>
        <tbody>
        <tr>
              <td><?php echo e($user->email); ?></td>
              <td><?php echo e($user->diabetic); ?></td>
              <td><?php echo e($user->created_at); ?></td>
            </tr>
        </tbody>
          </table>


    <a href="<?php echo e(route('recomendaciones.index')); ?>" class="btn btn-info">Volver</a>
    <a  class="btn btn-warning" href="<?php echo e(route('user.edit', $user)); ?>">Modificar</a>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/josefdez/public_html/repositorios/laravel/20190508-PortalDiabetes-PIDAW/PortalDiabetes/resources/views/user/show.blade.php ENDPATH**/ ?>