<?php $__env->startSection('content'); ?>

<section id="about" class="about-section text-center">
  <div class="container">
    <div class="row">
      <div class="col-lg-8 mx-auto">
        <p class="h1">Crear categoria</p>
       <form name="f1" action="<?php echo e(route('category.store')); ?>" method="POST">
          <!-- CONTROLAMOS LOS ERRORES DEL VALIDATE STORE -->
          <?php echo csrf_field(); ?>
          <?php if($errors->any): ?>
          <div>

            <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $el_error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li class="alert alert-danger"><?php echo e($el_error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

          </div>
          <?php endif; ?>

          <div class="form-group">
            <label for="nombre">Nombre</label>
            <input type="text" name="nombre" class="form-control" id="exampleFormControlFile1">
          </div>

          <div class="form-group">
            <label for="color">Color</label>
            <input type="color"  name="color" class="form-control" id="exampleFormControlFile1">
          </div>

          <div class="form-group">
            <label for="etiqueta">Etiqueta</label>
            <input type="text" name="etiqueta" class="form-control" id="exampleFormControlFile1">
          </div>

          <div class="form-group">

            <input type="submit" name="btn_env" class="btn btn-success" id="exampleFormControlFile1" value="Crear">
          </div>

        </form>

      </div>
    </div>

  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/josefdez/public_html/repositorios/laravel/20190508-PortalDiabetes-PIDAW/PortalDiabetes/resources/views/chattercategory/create.blade.php ENDPATH**/ ?>