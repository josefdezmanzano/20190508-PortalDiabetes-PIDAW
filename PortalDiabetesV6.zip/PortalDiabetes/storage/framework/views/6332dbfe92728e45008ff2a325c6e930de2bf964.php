<?php $__env->startSection('content'); ?>

<section id="about" class="about-section text-center">
  <div class="container">
    <div class="row">
      <div class="col-lg-8 mx-auto">
        <?php if(Session::has('message')): ?>
        <div class="alert alert-info"><?php echo e(Session::get('message')); ?></div>
        <?php endif; ?>
      </div>
    </div>

    <center><h1 style="text-align: center;font-family: 'Staatliches', cursive;">Categorias</h1></center>

    <table class="table table-sm">
        <thead>
          <tr>
            <th scope="col">ID</th>
            <th scope="col">NOMBRE</th>
            <th scope="col">COLOR</th>
            <th scope="col">ETIQUETA</th>
            <th scope="col">Acciones</th>

        </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <tr>
            <th scope="row"><?php echo e($categoria->id); ?></th>
            <td><?php echo e($categoria->name); ?></td>
            <td bgcolor="<?php echo e($categoria->color); ?>"></td>
            <td><?php echo e($categoria->slug); ?></td>

            <td>
                <a  class="btn btn-warning" href="<?php echo e(route('category.edit', $categoria)); ?>">Modificar</a>
                <form style="display: inline;" action="<?php echo e(route('category.destroy',$categoria->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-danger" type="submit">Borrar</button>
                </form>

            </td>


        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($categorias->links()); ?>

        </tbody>
      </table>



  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/josefdez/public_html/repositorios/laravel/20190508-PortalDiabetes-PIDAW/PortalDiabetes/resources/views/chattercategory/index.blade.php ENDPATH**/ ?>