    </div>
</div>
<?php /**PATH /home/josefdez/public_html/repositorios/laravel/20190508-PortalDiabetes-PIDAW/PortalDiabetes/resources/views/vendor/charts/_partials/loader/container-bottom.blade.php ENDPATH**/ ?>