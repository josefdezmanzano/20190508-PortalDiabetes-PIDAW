<?php $__env->startSection('content'); ?>

<section id="about" class="about-section text-center">
  <div class="container">
    <div class="row">
      <div class="col-lg-8 mx-auto">
        <?php if(Session::has('message')): ?>
        <div class="alert alert-info"><?php echo e(Session::get('message')); ?></div>
        <?php endif; ?>
      </div>
    </div>

    <center><h1 style="text-align: center;font-family: 'Staatliches', cursive;">Tus mediciones</h1></center>

  <a style=' text-align: right;float: right;' class="btn btn-secondary m-3" href="<?php echo e(route('chart')); ?>">Grafico</a>
    <table class="table table-sm">
        <thead>
          <tr>
            <th scope="col">Usuario</th>
            <th scope="col">Glucosa(mmg/dl)</th>
            <th scope="col">Momento</th>
            <th scope="col">Insulina Rapida</th>
            <th scope="col">Insulina Lenta</th>
            <th scope="col">Raciones</th>
            <th scope="col">Fecha de medicion</th>
            <th scope="col">Fecha de ultima modificación</th>
            <th scope="col">Acciones</th>

        </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $mediciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medicion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <tr>
            <th scope="row"><?php echo e($medicion->users->name); ?></th>
            <td><?php echo e($medicion->glucose); ?></td>
            <td><?php echo e($medicion->momento); ?></td>
            <td><?php echo e($medicion->rapidActingInsulin); ?></td>
            <td><?php echo e($medicion->longActingInsulin); ?></td>
            <td><?php echo e($medicion->rations); ?></td>
            <td><?php echo e($medicion->created_at); ?></td>
            <td><?php echo e($medicion->updated_at); ?></td>
            <td>
                <a  class="btn btn-warning" href="<?php echo e(route('mediciones.edit', $medicion)); ?>">Modificar</a>
                <a  href="<?php echo e(route('mediciones.show', $medicion->id)); ?>" class="btn btn-info">Detalles</a>

                <form style="display: inline;" action="<?php echo e(route('mediciones.destroy',$medicion->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-danger" type="submit">Borrar</button>
                </form>

            </td>


        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($mediciones->links()); ?>

        </tbody>
      </table>



  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/josefdez/public_html/repositorios/laravel/20190508-PortalDiabetes-PIDAW/PortalDiabetes/resources/views/mediciones/index.blade.php ENDPATH**/ ?>