<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/josefdez/public_html/repositorios/laravel/20190508-PortalDiabetes-PIDAW/PortalDiabetes/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>