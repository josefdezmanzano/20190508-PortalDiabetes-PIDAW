<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Hilo extends Model
{
    //
}
