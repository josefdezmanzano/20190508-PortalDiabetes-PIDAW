<?php

namespace App\Http\Controllers;

use App\Hilo;
use Illuminate\Http\Request;

class HiloController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Hilo  $hilo
     * @return \Illuminate\Http\Response
     */
    public function show(Hilo $hilo)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Hilo  $hilo
     * @return \Illuminate\Http\Response
     */
    public function edit(Hilo $hilo)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Hilo  $hilo
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Hilo $hilo)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Hilo  $hilo
     * @return \Illuminate\Http\Response
     */
    public function destroy(Hilo $hilo)
    {
        //
    }
}
