@extends('plantilla.plantilla')
@section('contenido')

<h2 class="container text-center mt-3">Usuarios</h2>
         
@endsection